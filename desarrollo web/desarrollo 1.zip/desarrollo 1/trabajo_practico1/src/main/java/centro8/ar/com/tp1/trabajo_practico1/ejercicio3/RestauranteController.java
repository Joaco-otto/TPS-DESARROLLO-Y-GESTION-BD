package centro8.ar.com.tp1.trabajo_practico1.ejercicio3;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/menu")
@RestController
public class RestauranteController {

    private final List<Plato> platos= Arrays.asList(
            new Plato(1, "Milanesa con papas", 2500, "Milanesa de carne con papas fritas"),
            new Plato(2, "Pizza Muzzarella", 3000, "Pizza a la piedra con muzzarella"),
            new Plato(3, "Ensalada César", 2200, "Lechuga, pollo, croutons y aderezo César"),
            new Plato(4, "Spaghetti Bolognesa", 2800, "Pasta italiana con salsa bolognesa"),
            new Plato(5, "Empanadas", 1800, "Docena de empanadas variadas")
    );

    @GetMapping("/plato")
    public String getPlato(@RequestParam int numero) {
        return platos.stream()
                .filter(p -> p.numero() == numero)
                .findFirst()
                .map(Plato::toString)
                .orElse("No se encontró el plato con número " + numero);
    }
}

record Plato(int numero, String nombre, double precio, String descripcion) {
    @Override
    public String toString() {
        return String.format("Plato %d: %s - $%.2f (%s)", numero, nombre, precio, descripcion);
    }

}






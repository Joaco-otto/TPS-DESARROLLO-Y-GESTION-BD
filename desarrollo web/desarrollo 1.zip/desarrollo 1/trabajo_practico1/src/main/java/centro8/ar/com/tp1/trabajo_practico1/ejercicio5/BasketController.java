package centro8.ar.com.tp1.trabajo_practico1.ejercicio5;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping
@RestController
public class BasketController {


 private final List<Jugador> jugadores = new ArrayList<>();

    @PostMapping("/alta")
    public String altaJugadores(@RequestBody List<Jugador> nuevos) {
        jugadores.addAll(nuevos);

        double promedio = jugadores.stream()
                .mapToDouble(Jugador::estatura)
                .average()
                .orElse(0);

        return String.format("Se cargaron %d jugadores. Promedio de estatura: %.2f mts.",
                jugadores.size(), promedio);
    }
}

record Jugador(int id, String dni, String nombre, String apellido, int edad, double peso, double estatura) {}



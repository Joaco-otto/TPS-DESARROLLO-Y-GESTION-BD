package centro8.ar.com.tp1.trabajo_practico1.ejercicio2;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/promedio")
public class PromedioController {
   @GetMapping("/promedio")
    public String calcularPromedio(
            @RequestParam double nota1,
            @RequestParam double nota2,
            @RequestParam double nota3) {

        double promedio = (nota1 + nota2 + nota3) / 3;
        return String.format("El promedio de las notas %.2f, %.2f y %.2f es: %.2f", 
                              nota1, nota2, nota3, promedio);
    }


}


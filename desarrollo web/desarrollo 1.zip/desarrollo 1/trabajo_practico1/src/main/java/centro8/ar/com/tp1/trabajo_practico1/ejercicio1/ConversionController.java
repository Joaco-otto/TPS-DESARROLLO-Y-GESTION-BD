package centro8.ar.com.tp1.trabajo_practico1.ejercicio1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/conversion")

public class ConversionController {
    private static final double GALONES_A_LITROS = 3.78541;
     @GetMapping("/galones-a-litros")

    public String convertir(@RequestParam double galones) {
        double litros = galones * GALONES_A_LITROS;
        return String.format("%.2f galones son %.2f litros", galones, litros);
    }

}

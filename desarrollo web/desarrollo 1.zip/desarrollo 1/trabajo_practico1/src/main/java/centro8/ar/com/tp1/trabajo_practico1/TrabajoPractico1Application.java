package centro8.ar.com.tp1.trabajo_practico1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoPractico1Application {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoPractico1Application.class, args);
	}

}

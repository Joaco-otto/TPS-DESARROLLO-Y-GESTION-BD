package centro8.ar.com.tp1.trabajo_practico1.ejercicio4;

import java.time.LocalDate;
import java.time.Period;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RequestMapping("/Pacientes")
@RestController

public class OdontologoController {private final List<Paciente> pacientes = Arrays.asList(
            new Paciente(1, "40123456", "Juan", "Pérez", LocalDate.of(2008, 5, 12)),
            new Paciente(2, "38987654", "María", "Gómez", LocalDate.of(1995, 3, 20)),
            new Paciente(3, "42111222", "Lucas", "Rodríguez", LocalDate.of(2010, 8, 30))
    );

    @GetMapping("/todos")
    public List<Paciente> getTodos() {
        return pacientes;
    }

    @GetMapping("/menores")
    public List<Paciente> getMenores() {
        LocalDate hoy = LocalDate.now();
        return pacientes.stream()
                .filter(p -> Period.between(p.fechaNacimiento(), hoy).getYears() < 18)
                .toList();
    }
}

record Paciente(int id, String dni, String nombre, String apellido, LocalDate fechaNacimiento) {}



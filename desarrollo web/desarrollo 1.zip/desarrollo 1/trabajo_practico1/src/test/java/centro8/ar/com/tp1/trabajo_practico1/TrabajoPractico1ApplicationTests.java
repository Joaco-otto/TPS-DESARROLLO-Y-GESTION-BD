package centro8.ar.com.tp1.trabajo_practico1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoPractico1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

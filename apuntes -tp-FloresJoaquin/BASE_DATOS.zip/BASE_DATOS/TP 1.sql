use pubs;

-- 1
CREATE VIEW vista_libros
AS
    SELECT 
        t.title       AS titulo,
        CONCAT(a.au_fname, ' ', a.au_lname) AS autor,
        t.price       AS precio
    FROM titles t
    INNER JOIN titleauthor ta ON t.title_id = ta.title_id
    INNER JOIN authors a ON ta.au_id = a.au_id;

select * from vista_libros;

-- 2
CREATE VIEW vista_libros_detalle
AS
    SELECT 
        t.title  AS titulo,
        CONCAT(a.au_fname, ' ', a.au_lname) AS autor,
        t.price  AS precio,
        t.type   AS tipo
    FROM titles t
    INNER JOIN titleauthor ta ON t.title_id = ta.title_id
    INNER JOIN authors a ON ta.au_id = a.au_id;

SELECT * FROM vista_libros_detalle;

-- 3
CREATE VIEW vista_libros_publicacion
AS
    SELECT 
        t.title  AS titulo,
        CONCAT(a.au_fname, ' ', a.au_lname) AS autor,
        t.price  AS precio,
        t.pubdate AS fecha_publicacion
    FROM titles t
    INNER JOIN titleauthor ta ON t.title_id = ta.title_id
    INNER JOIN authors a ON ta.au_id = a.au_id;

SELECT * FROM vista_libros_publicacion;

-- 4
CREATE VIEW vista_libros_ventas
AS
    SELECT 
        t.title  AS titulo,
        CONCAT(a.au_fname, ' ', a.au_lname) AS autor,
        t.price  AS precio,
        s.qty    AS cantidad_vendida
    FROM sales s
    INNER JOIN titles t ON s.title_id = t.title_id
    INNER JOIN titleauthor ta ON t.title_id = ta.title_id
    INNER JOIN authors a ON ta.au_id = a.au_id;

SELECT * FROM vista_libros_ventas;

-- 5 
CREATE VIEW vista_libros_ventas_tienda
AS
    SELECT 
        st.stor_name AS tienda,
        t.title      AS titulo,
        CONCAT(a.au_fname, ' ', a.au_lname) AS autor,
        t.price      AS precio,
        SUM(s.qty)   AS cantidad_vendida
    FROM sales s
    INNER JOIN stores st ON s.stor_id = st.stor_id
    INNER JOIN titles t ON s.title_id = t.title_id
    INNER JOIN titleauthor ta ON t.title_id = ta.title_id
    INNER JOIN authors a ON ta.au_id = a.au_id
	GROUP BY st.stor_name, t.title, a.au_fname, a.au_lname, t.price;

SELECT * FROM vista_libros_ventas_tienda;

-- 6 
CREATE VIEW vista_libros_ventas_tipo
AS
    SELECT 
        t.type  AS tipo,
        t.title AS titulo,
        CONCAT(a.au_fname, ' ', a.au_lname) AS autor,
        t.price AS precio,
        SUM(s.qty) AS cantidad_vendida
    FROM sales s
    INNER JOIN titles t ON s.title_id = t.title_id
    INNER JOIN titleauthor ta ON t.title_id = ta.title_id
    INNER JOIN authors a ON ta.au_id = a.au_id
    GROUP BY t.type, t.title, a.au_fname, a.au_lname, t.price;

SELECT * FROM vista_libros_ventas_tipo;

-- 7
CREATE VIEW vista_libros_ventas_tienda_tipo
AS
    SELECT 
        st.stor_name AS tienda,
        t.type      AS tipo,
        t.title     AS titulo,
        CONCAT(a.au_fname, ' ', a.au_lname) AS autor,
        t.price     AS precio,
        SUM(s.qty)  AS cantidad_vendida
    FROM sales s
    INNER JOIN stores st ON s.stor_id = st.stor_id
    INNER JOIN titles t ON s.title_id = t.title_id
    INNER JOIN titleauthor ta ON t.title_id = ta.title_id
    INNER JOIN authors a ON ta.au_id = a.au_id
    GROUP BY st.stor_name, t.type, t.title, a.au_fname, a.au_lname, t.price;

SELECT * FROM vista_libros_ventas_tienda_tipo;




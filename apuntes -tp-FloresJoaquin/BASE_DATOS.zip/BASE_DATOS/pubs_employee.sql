-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: pubs
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `emp_id` int NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `minit` char(1) DEFAULT NULL,
  `lname` varchar(30) NOT NULL,
  `job_id` smallint NOT NULL,
  `job_lvl` tinyint DEFAULT NULL,
  `pub_id` char(4) NOT NULL,
  `hire_date` datetime NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Philip','T','Cramer',2,127,'9952','1990-09-03 00:00:00'),(2,'Ann','M','Devon',3,127,'9952','1991-12-07 00:00:00'),(3,'Francisco','','Chang',4,90,'9952','1992-01-15 00:00:00'),(4,'Laurence','A','Lebihan',5,50,'0736','1991-04-10 00:00:00'),(5,'Paul','X','Henriot',5,45,'0877','1993-07-01 00:00:00'),(6,'Sven','K','Ottlieb',5,80,'1389','1990-08-14 00:00:00'),(7,'Rita','B','Muller',5,100,'1622','1994-02-23 00:00:00'),(8,'Maria','J','Pontes',5,40,'1756','1994-03-12 00:00:00'),(9,'Janine','Y','Labrune',5,60,'9901','1993-09-07 00:00:00'),(10,'Carlos','F','Hernadez',5,30,'9999','1995-10-21 00:00:00'),(11,'Victoria','P','Ashworth',6,127,'0877','1992-01-30 00:00:00'),(12,'Lesley','','Brown',7,120,'0877','1993-11-02 00:00:00'),(13,'Anabela','R','Domingues',8,100,'0877','1990-12-04 00:00:00'),(14,'Martine','','Rance',9,75,'0877','1992-12-31 00:00:00'),(15,'Peter','H','Franken',10,75,'0877','1990-11-09 00:00:00'),(16,'Daniel','B','Tonini',11,75,'0877','1994-10-22 00:00:00'),(17,'Helen','','Bennett',12,35,'0877','1990-06-11 00:00:00'),(18,'Paolo','M','Accorti',13,35,'0877','1994-05-27 00:00:00'),(19,'Elizabeth','N','Lincoln',14,35,'0877','1992-03-25 00:00:00'),(20,'Matti','G','Karttunen',6,58,'0736','1993-01-16 00:00:00'),(21,'Palle','D','Ibsen',7,60,'0736','1990-01-19 00:00:00'),(22,'Mary','M','Saveley',8,98,'0736','1990-12-02 00:00:00'),(23,'Gary','H','Thomas',9,122,'0736','1992-12-26 00:00:00'),(24,'Martin','F','Sommer',10,127,'0736','1990-05-28 00:00:00'),(25,'Roland','','Mendel',11,127,'0736','1991-07-11 00:00:00'),(26,'Howard','A','Snyder',12,100,'0736','1994-04-16 00:00:00'),(27,'Timothy','P','O\'Rourke',13,30,'0736','1992-03-20 00:00:00'),(28,'Karin','F','Josephs',14,43,'0736','1995-12-25 00:00:00'),(29,'Diego','W','Roel',6,127,'1389','1991-11-18 00:00:00'),(30,'Maria','','Larsson',7,127,'1389','1995-12-11 00:00:00'),(31,'Paula','S','Parente',8,125,'1389','1993-10-03 00:00:00'),(32,'Margaret','A','Smith',9,78,'1389','1991-05-30 00:00:00'),(33,'Aria','','Cruz',10,87,'1389','1994-05-09 00:00:00'),(34,'Miguel','A','Paolino',11,112,'1389','1991-12-20 00:00:00'),(35,'Yoshi','','Latimer',12,32,'1389','1995-10-24 00:00:00'),(36,'Carine','G','Schmitt',13,64,'1389','1994-03-01 00:00:00'),(37,'Pedro','S','Afonso',14,89,'1389','1995-04-30 00:00:00'),(38,'Annette','','Roulet',6,127,'9999','1990-06-28 00:00:00'),(39,'Helvetius','A','Nagy',7,120,'9999','1988-10-09 00:00:00'),(40,'Manuel','','Pereira',8,101,'9999','1991-06-18 00:00:00'),(41,'Karla','J','Jablonski',9,127,'9999','1997-01-12 00:00:00'),(42,'Pirkko','O','Koskitalo',10,80,'9999','1998-06-01 00:00:00'),(43,'Patricia','C','McKenna',11,127,'9999','1991-11-02 00:00:00');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-04 21:25:37

-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: pubs
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `titles`
--

DROP TABLE IF EXISTS `titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `titles` (
  `title_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(80) NOT NULL,
  `type` char(12) NOT NULL,
  `pub_id` char(4) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `advance` float DEFAULT NULL,
  `royalty` int DEFAULT NULL,
  `ytd_sales` int DEFAULT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `pubdate` datetime NOT NULL,
  PRIMARY KEY (`title_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `titles`
--

LOCK TABLES `titles` WRITE;
/*!40000 ALTER TABLE `titles` DISABLE KEYS */;
INSERT INTO `titles` VALUES (1,'Secrets of Silicon Valley','popular_comp','1389',20,8000,10,4095,'Muckraking reporting on the world\'s largest computer hardware and software manufacturers.','1990-09-00 00:00:00'),(2,'The Busy Executive\'s Database Guide','business','1389',19.99,5000,10,4095,'An overview of available database systems with emphasis on common business applications. Illustrated.','1990-08-14 00:00:00'),(3,'Emotional Security: A New Algorithm','psychology','0736',7.99,4000,10,3336,'Protecting yourself and your loved ones from undue emotional stress in the modern world. Use of computer and nutritional aids emphasized.','1990-11-09 00:00:00'),(4,'Prolonged Data Deprivation: Four Case Studies','psychology','0736',19.99,2000,10,4072,'What happens when the data runs dry?  Searching evaluations of information-shortage effects.','1990-12-04 00:00:00'),(5,'Cooking with Computers: Surreptitious Balance Sheets','business','1389',11.95,5000,10,3876,'Helpful hints on how to use your electronic resources to the best advantage.','1990-11-09 00:00:00'),(6,'Silicon Valley Gastronomic Treats','mod_cook','0877',19.99,0,12,2032,'Favorite recipes for quick, easy, and elegant meals.','1992-03-20 00:00:00'),(7,'Sushi, Anyone?','trad_cook','0877',14.99,8000,10,4095,'Detailed instructions on how to make authentic Japanese sushi in your spare time.','1994-03-01 00:00:00'),(8,'Fifty Years in Buckingham Palace Kitchens','trad_cook','0877',11.95,4000,14,15096,'More anecdotes from the Queen\'s favorite cook describing life among English royalty. Recipes, techniques, tender vignettes.','1998-06-01 00:00:00'),(9,'But Is It User Friendly?','popular_comp','1389',22.95,7000,16,8780,'A survey of software for the naive user, focusing on the \'friendliness\' of each.','1997-01-12 00:00:00'),(10,'You Can Combat Computer Stress!','business','0736',2.99,10125,24,18722,'The latest medical and psychological techniques for living with the electronic office. Easy-to-understand explanations.','1991-11-02 00:00:00'),(11,'Is Anger the Enemy?','psychology','0736',10.95,2275,12,2045,'Carefully researched study of the effects of strong emotions on the body. Metabolic charts included.','1994-05-27 00:00:00'),(12,'Life Without Fear','psychology','0736',7,6000,10,111,'New exercise, meditation, and nutritional techniques that can reduce the shock of daily interactions. Popular audience. Sample menus included, exercise video available separately.','1992-03-25 00:00:00'),(13,'The Gourmet Microwave','mod_cook','0877',2.99,15000,24,22246,'Traditional French gourmet recipes adapted for modern microwave cooking.','1993-01-16 00:00:00'),(14,'Onions, Leeks, and Garlic: Cooking Secrets of the Mediterranean','trad_cook','0877',20.95,7000,10,375,'Profusely illustrated in color, this makes a wonderful gift book for a cuisine-oriented friend.','1990-01-19 00:00:00'),(15,'The Psychology of Computer Cooking','','0877',NULL,NULL,NULL,NULL,NULL,'1992-03-25 00:00:00'),(16,'Straight Talk About Computers','business','1389',19.99,5000,10,4095,'Annotated analysis of what computers can do for you: a no-hype guide for the critical user.','1994-05-27 00:00:00'),(17,'Computer Phobic AND Non-Phobic Individuals: Behavior Variations','psychology','0877',21.59,7000,10,375,'A must for the specialist, this book examines the difference between those who hate and fear computers and those who don\'t.','1993-01-16 00:00:00'),(18,'Net Etiquette','popular_comp','1389',NULL,NULL,NULL,NULL,'A must-read for computer conferencing.','1990-12-02 00:00:00'),(19,'','',NULL,NULL,NULL,NULL,NULL,NULL,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `titles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-04 21:25:37
